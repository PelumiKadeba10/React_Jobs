import Navbar from "../components/navbar"

function Jobs() {
   return (
    <div>
      <Navbar />
      
    </div>
   )
 }

 export default Jobs